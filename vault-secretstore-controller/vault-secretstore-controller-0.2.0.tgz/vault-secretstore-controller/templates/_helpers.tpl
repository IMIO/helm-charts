{{/*
Expand the name of the chart.
*/}}
{{- define "vault-secretstore-controller.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "vault-secretstore-controller.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart label.
*/}}
{{- define "vault-secretstore-controller.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels.
*/}}
{{- define "vault-secretstore-controller.labels" -}}
helm.sh/chart: {{ include "vault-secretstore-controller.chart" . }}
{{ include "vault-secretstore-controller.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels.
*/}}
{{- define "vault-secretstore-controller.selectorLabels" -}}
app.kubernetes.io/name: {{ include "vault-secretstore-controller.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
ClusterRole/ClusterRoleBinding name. Cluster-scoped objects have no
namespace field to disambiguate them, so the release namespace is folded
into the name instead — unlike rbac-hobo.yaml's namespaced Role, which
only needs a purpose suffix (e.g. "-hobo-exec").
*/}}
{{- define "vault-secretstore-controller.clusterRoleName" -}}
{{- printf "%s-%s" (include "vault-secretstore-controller.fullname" .) .Release.Namespace | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Service account name.
*/}}
{{- define "vault-secretstore-controller.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "vault-secretstore-controller.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
