# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Overview

An opinionated Helm chart for deploying Odoo ERP at IMIO. Intentionally scoped to IMIO's needs — not a general-purpose chart. Targets Odoo 16.0+ using the official Odoo Docker images rather than bitnami/odoo.

## Commands

```bash
# Lint the chart
helm lint .
helm lint -f test/local.yaml .

# Render templates (dry-run)
helm template odoo . -f test/local.yaml --namespace odoo

# Update dependencies (PostgreSQL from CloudPirates)
helm dep up

# Deploy to a local cluster
helm upgrade odoo . -f test/local.yaml --namespace odoo --create-namespace --install
```

The `helmlint.sh` script is used as a pre-commit hook and runs `helm lint` on changed files.

## Architecture

### Deployment Design

The main deployment (`templates/deployment.yaml`) runs **two containers** in a single pod:

1. **Nginx** — reverse proxy that handles HTTP (port 80→8069) and long-polling WebSocket (port 80→8072), gzip compression, and X-Forwarded headers for SSL termination. `nginx.proxyTimeouts.read`/`.send` render `proxy_read_timeout`/`proxy_send_timeout` in `location /` only, and only when non-empty (empty, the default, keeps nginx's 60 s and a byte-identical `nginx.conf`); `read` must be >= `odoo.limit_time_real`, which the chart documents rather than derives or checks.
2. **Odoo** — the ERP application (port 8069 HTTP, port 8072 long-polling)

Strategy is always `Recreate` by default (no rolling updates, since Odoo requires a single writer).

### Services

Three separate services expose different ports:
- `odoo-nginx` (ClusterIP :80) — external entry point, routes to Nginx
- `odoo-odoo` (ClusterIP :8069) — internal Odoo HTTP
- `odoo-odoo-longpolling` (ClusterIP :8072) — WebSocket/chat

### Ingresses

`templates/ingress.yaml` renders the main `ingress` (`<fullname>`, gated on `ingress.enabled`) plus one Ingress per `extraIngresses` entry (`<fullname>-<name>`, `name` required — e.g. a private URL next to the public one). All go through the `..ingress` helper (`(dict "ctx" $ "name" <resource name> "ing" <spec>)`), so they share the backend (`<fullname>-nginx`, or `<fullname>-maintenance-page` when `maintenance.enabled`) and the `tpl` rendering of className/hosts/paths/tls.

### Templated values (`tpl`)

A set of identity/routing value fields is rendered through `tpl` (context `$`), so a value may embed `{{ .Values.* }}` expressions referencing other values (e.g. `fullnameOverride: "{{ .Values.instance_id }}"`) — designed for an ArgoCD `ApplicationSet` that merges a shared defaults file with per-instance `values.yaml`. Rendered fields: `..name`/`..fullname` (`nameOverride`/`fullnameOverride`), the `..dbHost`/`..dbName`/`..dbUser` helpers (`externalDatabase.host`/`.name`/`.user` + `postgresql.auth.database`/`.username`), `externalsecrets.odooKey`/`postgresqlKey`/`secretStoreRef.name`/`properties.odoo.*.key` (the per-credential key overrides — the `property` names are **not** `tpl`-rendered), `externalsecrets.s3.key`/`.secretName` (the `s3.properties` map is **not** `tpl`-rendered), and ingress (main + `extraIngresses`) `className`/`hosts[].host`/`paths[].path`/`tls[].secretName`/`tls[].hosts[]`. **Never** `tpl`-rendered: any password (`..dbPassword`), `..dbPort`, and the `..odooConf` body — the last one carries literal external-secrets placeholders (`{{ .postgresqlPassword }}`, `{{ .odooAdminPasswd }}`) that must reach the operator unrendered. `tpl` on a value with no `{{ }}` returns it unchanged, so existing plain-value installs are unaffected.

### Configuration and Secrets

Odoo is configured via `odoo.conf` injected as a Kubernetes Secret. Three mutually exclusive approaches:

1. **Default**: Secrets generated from `values.yaml` values (`existingSecret.enabled: false`, `externalsecrets.enabled: false`)
2. **Existing Secret**: Reference a pre-created Kubernetes Secret (`existingSecret.enabled: true`)
3. **External Secrets**: Vault integration via external-secrets.io operator (`externalsecrets.enabled: true`)

With **External Secrets**, each odoo.conf credential picks its own Vault key via `externalsecrets.properties.odoo.<cred>.{key,property}` (helper `..externalsecrets.odooConfData`, shared by the normal + hook ExternalSecrets). The DB password (`postgresqlPassword` → odoo.conf `db_password`) defaults its `key` to `externalsecrets.postgresqlKey` — the same key the bundled-PostgreSQL secret reads — so the DB password lives in Vault **once** and is shared rather than duplicated under `odooKey` (falls back to `odooKey` when `postgresqlKey` is unset, e.g. an external DB). The Odoo master password (`adminPasswd` → `admin_passwd`) defaults its `key` to `odooKey`. Any `key` can be overridden to point a credential at a different Vault key.

The `odoo.conf` secret is **split by lifecycle** (generated + externalsecrets backends):
- `<fullname>-odoo-conf` — a **normal** (Helm-tracked) Secret mounted by the Odoo + cron deployments. Tracked in `helm get manifest`, rollback-aware, stable across upgrades.
- `<fullname>-odoo-conf-hook` — a **hook** copy mounted only by the init/update Jobs (which run at `pre-install`, before normal resources exist). Rendered only when `init.enabled || update.enabled`.

Both copies share the same `odoo.conf` content via the `..odooConf` helper (single source of truth). With `existingSecret`, the user's single pre-existing `<fullname>-odoo-conf` serves both — no hook copy. See the pre-install dependency model below for why the split exists.

**S3 object storage credentials** (`externalsecrets.s3`, externalsecrets backend only, default off) are the one credential the chart delivers as **environment variables** rather than through `odoo.conf`. One Vault key (`s3.key`, `tpl`-rendered, so it can be derived per instance from `instance_id`) is fanned out into env vars by the `s3.properties` map (env var name → Vault property; defaults match the Garage layout, an entry set to `null` is skipped). Helpers: `..s3.enabled` (gate), `..s3SecretName` (default `<fullname>-s3`), `..externalsecrets.s3Data` (the shared `data:` list — render it with `trim | nindent 2`, each entry starts with a newline).

Injection goes through `..envFromList`, called as `(dict "ctx" $ "extraEnvFrom" <list> "hook" <bool>)` — it returns the caller's `extraEnvFrom` plus the S3 `secretRef`, and is the single `envFrom` source for `deployment.yaml`, `cron-deployment.yaml` and `..hookOdooContainer`. The S3 secret is **split by lifecycle** exactly like `odoo.conf`: a normal `<fullname>-s3` plus, when `init.enabled || update.enabled`, a `pre-install,pre-upgrade` hook copy `<fullname>-s3-hook` that the Jobs consume (`hook: true`). Without the hook copy a fresh install with `init.enabled` would leave the Job pod in `CreateContainerConfigError` until Helm times out, since `envFrom` would point at a Secret that does not exist yet.

Nginx configuration is in a ConfigMap (`templates/configmap.yaml`).

### Database init & update (Helm hook Jobs)

DB lifecycle is handled by Helm hook Jobs in `templates/hooks/`. Both Jobs run on **`pre-install,pre-upgrade`**, so they execute *before* the Odoo/cron deployments are (re)applied. Each Job's `prepare` initContainer scales any running Odoo/cron to 0 (a no-op on a fresh install, since the deployments don't exist yet), and a `wait-for-db` initContainer (`odoo.hooks.waitForDb`) blocks on the DB host:port. **No install-time replica gating or scale-up hook is needed** — at `pre-install` the deployments don't exist; afterwards Helm creates them at their normal replicas, and on upgrade Helm re-applies them, bringing Odoo back up.

- **Init** (`odoo.init.enabled`) — `hooks/job-init.yaml`, hook-weight `0`. Runs `odoo -i <modules> -d <db> --stop-after-init`. `enabled` is a **one-shot intent**: set it true to initialise on install, or to **re-initialise after trashing the DB** (`helm upgrade` with `odoo.init.enabled=true`), then set it back to false (left on, every upgrade re-runs `odoo -i`).
- **Update** (`odoo.update.enabled`, default **false**) — `hooks/job-update.yaml`, hook-weight `10` (so init at `0` completes first when both are enabled). Runs `odoo -u <modules> --stop-after-init`. Set true only for a version bump (downtime + migration); `odoo -u` needs an already-initialised DB.

RBAC for the scale-down lives in `hooks/rbac.yaml` (rendered when `init.enabled` **or** `update.enabled`, weight `-10`). The `prepare` initContainer image is `odoo.hooks.kubectlImage` (default `alpine/kubectl:1.36.1`). Hook Jobs mount only an `odoo.conf` secret (no PVC). (Multi-tenant / Indexed-Job support is planned for a later release.)

**Pre-install dependency model** (the hooks run *before* the chart's normal resources, so everything they
need is itself provisioned as a pre-install hook; a pod that mounts a not-yet-created secret stays in
`ContainerCreating` and kubelet retries the mount until it appears, so "synced during pre-install" is enough):
- **odoo.conf secret** — the Jobs run at `pre-install`, so they need a secret that exists *before* the chart's
  normal resources. Rather than force one secret to be both a pre-install hook and the deployment's persistent
  resource (the old approach made it a hook **unconditionally**, accepting: recreated each upgrade, absent from
  `helm get manifest`, not rollback-restored — all to dodge the hook↔normal flip that trips Helm's ownership
  check, `invalid ownership metadata`), the secret is **split by lifecycle**. The Jobs mount the hook copy via
  `..hookVolumes`; the deployment/cron mount the normal copy directly. Neither copy ever changes type, so neither
  trips the ownership check, and the hook copy is gated on `init.enabled || update.enabled`.
  - *generated/classic* — `templates/secrets.yaml` renders **two** Secrets: the normal `<fullname>-odoo-conf`
    (always) and, when `init/update` is enabled, the hook `<fullname>-odoo-conf-hook` (`pre-install,pre-upgrade`,
    weight `-15`, `before-hook-creation`).
  - *existingSecret* — the user's single `<fullname>-odoo-conf` pre-exists; mounted directly by both the Jobs
    (`..hookVolumes` drops the `-hook` suffix here) and the deployment. No hook copy.
  - *externalsecrets* — `templates/externalsecrets.yaml` renders a **normal** `ExternalSecret` (target
    `<fullname>-odoo-conf`, always) plus, when `init/update` is enabled, a **hook** `ExternalSecret` (target
    `<fullname>-odoo-conf-hook`, `pre-install,pre-upgrade`). The operator syncs each target during its phase;
    the Job's mount retries until it lands. (Helm's hook wait only blocks on Pods/Jobs, not CR status, so this
    relies on the operator syncing within `--timeout`.)
- **Bundled PostgreSQL** — Helm cannot deploy a subchart before the parent's pre-install hooks, so the bundled
  Postgres (`postgresql.enabled: true`) is not up when the hooks run. To use it with the hooks (dev/test),
  run Postgres itself as a pre-install hook via `postgresql.commonAnnotations` (`helm.sh/hook: pre-install`,
  weight below `0`) — see `test/local.yaml`. Production should use an external DB. The Jobs' DB connection
  resolves through the `..dbHost`/`..dbPort`/… helpers.

`before-hook-creation` is required on the hook copy (`<fullname>-odoo-conf-hook`): Helm Creates hook resources,
so a re-run on the next upgrade would otherwise fail with `already exists`.

> **Migration note** — In released versions `<fullname>-odoo-conf` is already a *normal* secret, so upgrading to
> the split layout is seamless (normal→normal). Only an intermediate dev build where `<fullname>-odoo-conf` was a
> *hook* would flip it hook→normal and hit `invalid ownership metadata`; if you ran such a build, delete the stale
> secret (`kubectl delete secret <release>-odoo-conf`) before upgrading, or reinstall.

Shared Job spec lives in `_helpers.tpl` helpers: `..hookOdooContainer`, `..hookVolumes`, `..hookScaleDownInitContainer` (the `prepare` scale-down) and `..hookWaitForDbInitContainer` (reused by both Jobs).

### Maintenance Mode

When `maintenance.enabled: true`, the chart:
- Scales the main Odoo deployment to 0 replicas
- Scales the cron deployment to 0 replicas (so scheduled actions don't write to the DB during migrations/restores)
- Deploys a maintenance page (custom HTML or default)
- Redirects Ingress traffic to the maintenance service

The update/re-init hooks reuse this same maintenance nginx but bring up their own `pre-upgrade` hook copy of the maintenance Deployment (`hooks/maintenance-hook.yaml`, gated by the `..maintenanceHook.enabled` helper: `update.enabled` **or** `init.enabled`, with `maintenancePage` + `ingress.enabled` or `extraIngresses`). It mounts **hook copies** of the config/HTML ConfigMaps (`<fullname>-default-conf-hook`, `<fullname>-maintenance-page-hook`, `pre-upgrade`, weight `-15`, `before-hook-creation`), rendered by the same `range` in `configmap.yaml` as the normal ones. It can't mount the normal ConfigMaps: ArgoCD maps `pre-upgrade` to `PreSync`, so on a fresh ArgoCD install the hook pod runs before they exist and sits in `ContainerCreating` forever (`configmap "<fullname>-default-conf" not found`). Crucially, that pod carries the chart's `selectorLabels` and a `nginx-http` port, so the existing `<fullname>-nginx` Service routes to it while Odoo is scaled to 0 — **the ingress is never modified** (an earlier `kubectl patch` approach was abandoned because Helm's 3-way merge does not revert out-of-band ingress edits when the rendered ingress manifest is unchanged). The hook is torn down once the upgrade hooks succeed, and the Service routes back to Odoo.

### Scheduled rollout restart

When `rolloutRestart.enabled: true`, `templates/cronjob-rollout-restart.yaml` renders a **CronJob** (`<fullname>-rollout-restart`) plus its own dedicated **ServiceAccount/Role/RoleBinding** (also `<fullname>-rollout-restart`). On its schedule the Job runs `kubectl rollout restart` + `kubectl rollout status` over a list of target deployments. These are **normal** (non-hook) resources — unlike the init/update hooks, the CronJob runs independently of install/upgrade.

The dedicated RBAC is deliberate: the chart's main ServiceAccount mounts no API token (`automountServiceAccountToken: false`), and the `<fullname>-hook` RBAC is hook-scoped and lacks the `watch` verb that `kubectl rollout status` needs. The Role grants `get`/`list`/`watch`/`patch` on `apps/deployments` in the release namespace; the pod sets `automountServiceAccountToken: true`. Image defaults to `odoo.hooks.kubectlImage`, securityContext reuses the chart's pod/container contexts (alpine/kubectl runs fine as uid 100). **Default targets** (empty `rolloutRestart.targets`): the main Odoo deployment `<fullname>`, plus `<fullname>-cron` when `cron.enabled`; an explicit `targets` list overrides this.

### ServiceMonitor (metrics)

When `serviceMonitor.enabled: true` (default **false**), `templates/servicemonitor.yaml` renders a Prometheus Operator **ServiceMonitor** (`monitoring.coreos.com/v1`, `<fullname>-service-monitor`) that scrapes Odoo metrics. Gated solely on its own `enabled` flag — no CRD-presence guard (same precedent as `externalsecrets.yaml`); requires the Prometheus Operator CRDs and an Odoo endpoint actually serving metrics at `serviceMonitor.path` (e.g. a metrics-exporting Odoo module). The chart only wires the scrape — it adds no metrics endpoint.

The selector uses **positive** `matchLabels` (`..selectorLabels` + `app.kubernetes.io/component: server`) rather than a `component != cron` exclusion. A ServiceMonitor selector matches a Service's **`metadata.labels`**, not its `spec.selector`; the `-odoo`/`-lp-odoo` Services previously carried `component: server` only in their `spec.selector`, so `templates/service.yaml` now also stamps `app.kubernetes.io/component: server` into their `metadata.labels` (mirroring how `cron-service.yaml` stamps `component: cron`). The `odoo-http` endpoint then narrows scraping to the `<fullname>-odoo` Service (`-lp-odoo` exposes `odoo-lp-http`, so it's matched by the selector but skipped by the port name; `-cron` carries `component: cron` and is excluded). Configurable via the Standard-scope `serviceMonitor.*` values: `labels`/`annotations` (the `labels` typically carry the operator's `release:` selector), `port`, `path`, `interval`, `scheme`, `scrapeTimeout`, `relabelings`, `metricRelabelings`.

### Health Checks

Both liveness and readiness probes for Odoo hit `/web/health` on the Odoo HTTP port. Liveness has a 120s initial delay; readiness has 30s. The Nginx sidecar probes hit `/healthz` on port 80, which returns 200 directly without proxying to Odoo.

### PostgreSQL

Database config is split into two clearly-scoped sections, with `postgresql.enabled` selecting which one Odoo reads:

- `postgresql.*` — the **bundled** [CloudPirates `postgres`](https://github.com/CloudPirates-io/helm-charts/tree/main/charts/postgres) subchart (OCI registry, official `docker.io/postgres` image), used when `postgresql.enabled: true` (dev/test). Aliased to `postgresql` in `Chart.yaml`, so the values key and the `<release>-postgresql` resource names are preserved. Odoo's connection comes from `postgresql.auth.*`, the host is auto-derived as `<release>-postgresql`, port `5432`. The image tag is pinned to a PostgreSQL **17.x** digest via `postgresql.image.tag`. Credentials: `auth.username`/`.password`/`.database` configure the **superuser** (this chart has no separate `postgresPassword`; the named user is the superuser and gets a same-named DB), or supply the password via `auth.existingSecret` (key `postgres-password`).
- `externalDatabase.*` — connection settings for an **external** PostgreSQL (e.g., CloudNativePG, recommended for production), used when `postgresql.enabled: false`. `externalDatabase.host` is required in this mode.

Connection resolution lives in the `..dbHost`/`..dbPort`/`..dbName`/`..dbUser`/`..dbPassword` helpers in `_helpers.tpl`, which switch source based on `postgresql.enabled`.

## Key Files

| File | Purpose |
|------|---------|
| `values.yaml` | All default configuration with inline comments |
| `templates/_helpers.tpl` | Shared template helpers (names, labels, selectors) |
| `templates/deployment.yaml` | Main Odoo + Nginx pod definition |
| `templates/secrets.yaml` | Generated `odoo.conf` secret — normal `<fullname>-odoo-conf` + gated hook `<fullname>-odoo-conf-hook` |
| `templates/configmap.yaml` | Nginx config and maintenance page HTML |
| `templates/externalsecrets.yaml` | Vault/external-secrets integration — `odoo.conf` + optional S3 credentials (`externalsecrets.s3`), each with a gated hook copy |
| `templates/servicemonitor.yaml` | Optional Prometheus Operator `ServiceMonitor` (gated on `serviceMonitor.enabled`) |
| `templates/hooks/` | Init / update hook Jobs (both `pre-install,pre-upgrade`; init weight `0` < update weight `10`), RBAC, maintenance-page hook |
| `templates/cronjob-rollout-restart.yaml` | Optional scheduled `kubectl rollout restart` CronJob + its dedicated `<fullname>-rollout-restart` RBAC (gated on `rolloutRestart.enabled`) |
| `test/local.yaml` | Development overrides (ingress enabled, `odoo.local` hostname) |

## CI/CD

- **Push / PR**: Runs `helm lint` + test via `IMIO/gha/helm-test-notify@v6`
- **Release**: Triggered on successful test on tag; publishes to `https://imio.github.io/helm-charts` via `IMIO/gha/helm-release-notify@v6`

Before creating and pushing a git tag, ensure `version` in `Chart.yaml` matches the tag. The release workflow is triggered by tag pushes and builds dependencies (the CloudPirates `postgres` OCI subchart) and packages the chart automatically.
